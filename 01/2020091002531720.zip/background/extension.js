var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var DarkReader;
(function (DarkReader) {
    var ICON_PATHS = {
        active_19: '../img/dr_active_19.png',
        active_38: '../img/dr_active_38.png',
        inactive_19: '../img/dr_inactive_19.png',
        inactive_38: '../img/dr_inactive_38.png'
    };
    var ALARMS = {
        DarkModeOn: 'DarkModeOn',
        DarkModeOff: 'DarkModeOff',
        NightModeOn: 'NightModeOn',
        NightModeOff: 'NightModeOff'
    };
    var SAVE_CONFIG_TIMEOUT = 1000;
    /**
     * Chrome extension.
     * Extension uses CSS generator to process opened web pages.
     */
    var Extension = (function (_super) {
        __extends(Extension, _super);
        /**
         * Creates a chrome extensions.
         * @param generator CSS-generator.
         */
        function Extension(generator) {
            var _this = this;
            _super.call(this);
            this.darkModeListener = function (alarm, _self) {
                /*console.log("darkModeListener config change ", alarm);*/
                if (alarm.name === ALARMS.DarkModeOn) {
                    /*console.log("DarkModeOn");*/
                    _self.config.mode = 1;
                }
                if (alarm.name === ALARMS.DarkModeOff) {
                    /*console.log("DarkModeOff config change");*/
                    _self.config.mode = 0;
                }
            };
            this.nightModeListener = function (alarm, _self) {
                /*console.log("nightModeListener config change ", alarm);*/
                if (alarm.name === ALARMS.NightModeOn) {
                    /*console.log("NightModeOn");*/
                    _self.config.nightMode = 1;
                }
                if (alarm.name === ALARMS.NightModeOff) {
                    /*console.log("NightModeOff");*/
                    _self.config.nightMode = 0;
                }
            };
            this.tabUpdateListener = function (tabId, info, tab) {
                console.log("Tab updated: " + tab.id + ", status: " + info.status);
                _this.addStyleToTab(tab);
            };
            this.tabReplaceListener = function (addedTabId, replacedTabId) {
                console.log("Tab " + replacedTabId + " replaced with " + addedTabId);
                chrome.tabs.get(addedTabId, function (tab) { return _this.addStyleToTab(tab); });
            };
            this.generator = generator;
            // Define properties
            xp.Model.property(this, 'enabled', false);
            xp.Model.property(this, 'config', null);
            xp.Model.property(this, 'configCopy', null);
            xp.Model.property(this, 'popupOpenCount', 0);
            xp.Model.property(this, 'fonts', []);
            // Handle config changes
            var changeReg = new xp.EventRegistrar();
            this.onPropertyChanged.addHandler(function (prop) {
                /*console.log(prop);*/
                if (_this.configCopy === null) {
                    _this.configCopy = Object["assign"]({}, _this.config);
                }
                /*console.log("onPropertyChanged ", this.config, this.configCopy);*/
                if (prop === 'enabled') {
                    _this.onAppToggle();
                }
                if (prop === 'config') {
                    changeReg.unsubscribeAll();
                    changeReg.subscribe(_this.config.onPropertyChanged, _this.onConfigPropChanged, _this);
                    changeReg.subscribe(_this.config.siteList.onCollectionChanged, _this.onConfigPropChanged, _this);
                    changeReg.subscribe(_this.config.blackList.onCollectionChanged, _this.onConfigPropChanged, _this);
                    changeReg.subscribe(_this.config.whiteList.onCollectionChanged, _this.onConfigPropChanged, _this);
                    _this.onConfigPropChanged();
                }
                if (prop === 'popupOpenCount') {
                    /*console.log("popupOpenCount saveUserSettings");*/
                    _this.saveUserSettings();
                }
            });
            // Default icon
            chrome.browserAction.setIcon({
                path: {
                    '19': ICON_PATHS.inactive_19,
                    '38': ICON_PATHS.inactive_38
                }
            });
            // Load user settings from Chrome storage
            this.loadUserSettings();
            var _self = this;
            // Subscribe on keyboard shortcut
            chrome.commands.onCommand.addListener(function (command) {
                if (command === 'toggle') {
                    /*console.log('Toggle command entered');*/
                    _this.enabled = !_this.enabled;
                }
                if (command === 'darkModeToggle') {
                    /*console.log('darkModeToggle command entered');*/
                    _self.config.mode = _self.config.mode === 0 ? 1 : 0;
                }
                if (command === 'nightModeToggle') {
                    /*console.log('nightModeToggle command entered');*/
                    _self.config.nightMode = _self.config.nightMode === 0 ? 1 : 0;
                }
                /*if (command === 'addSite') {
                    console.log('Add Site command entered');
                    this.toggleCurrentSite(null);
                }*/
            });
            // Load font list
            this.getFontList(function (fonts) { return _this.fonts = fonts; });
            // TODO: Try to remove CSS before ext disabling or removal.
            window.addEventListener('unload', function () {
                chrome.tabs.query({}, function (tabs) {
                    tabs.forEach(_this.removeStyleFromTab, _this);
                });
            });
            this.addAlarmListeners();
        }
        Extension.prototype.incrementPopupOpenCount = function (n) {
            if (this.popupOpenCount !== -1) {
                if (n === -1) {
                    this.popupOpenCount = n;
                }
                else {
                    this.popupOpenCount = this.popupOpenCount + n;
                }
            }
        };
        Extension.prototype.addAlarmListeners = function () {
            /**
                {
                    name: "myAlarm"
                    periodInMinutes: 1
                    scheduledTime: 1553197475830.527
                }
             */
            /*console.log("addAlarmListeners called");*/
            var _self = this;
            if (_self.darkAlarmListenerOn !== true) {
                /*chrome.alarms.onAlarm.addListener((alarm)=>{
                    console.log("onAlarm ", alarm);
                    if(alarm.name === ALARMS.NightModeOff || alarm.name === ALARMS.NightModeOn){
                        _self.nightModeListener(alarm, _self);
                    }
                    if(alarm.name === ALARMS.DarkModeOff || alarm.name === ALARMS.DarkModeOn){
                        _self.darkModeListener(alarm, _self)
                    }
                });*/
                _self.darkAlarmListenerOn = true;
                chrome.alarms.onAlarm.addListener(function (alarm) { _self.darkModeListener(alarm, _self); });
            }
            if (_self.nightAlarmListenerOn !== true) {
                _self.nightAlarmListenerOn = true;
                chrome.alarms.onAlarm.addListener(function (alarm) { _self.nightModeListener(alarm, _self); });
            }
        };
        Extension.prototype.removeAlarmListeners = function (name) {
            var _self = this;
            if (name === ALARMS.NightModeOff || name === ALARMS.NightModeOn) {
                chrome.alarms.onAlarm.removeListener(_self.nightModeListener);
                _self.nightAlarmListenerOn = false;
            }
            if (name === ALARMS.DarkModeOff || name === ALARMS.DarkModeOn) {
                chrome.alarms.onAlarm.removeListener(_self.darkModeListener);
                _self.darkAlarmListenerOn = false;
            }
        };
        /**
         * Returns info of active tab
         * of last focused window.
         */
        Extension.prototype.getActiveTabInfo = function (callback) {
            chrome.tabs.query({
                active: true,
                lastFocusedWindow: true
            }, function (tabs) {
                if (tabs.length === 1) {
                    var url = tabs[0].url;
                    var host = url.match(/^(.*?:\/{2,3})?(.+?)(\/|$)/)[2];
                    var info = {
                        url: url,
                        host: host,
                        isProtected: !canInjectScript(url),
                        isInDarkList: DarkReader.isUrlInList(url, DarkReader.DARK_SITES),
                    };
                    callback(info);
                }
                else {
                    if (DarkReader.DEBUG) {
                        throw new Error('Unexpected tabs count.');
                    }
                    console.error('Unexpected tabs count.');
                    callback({ url: '', host: '', isProtected: false, isInDarkList: false });
                }
            });
        };
        Extension.prototype.getTimeStamp = function (hhmm) {
            if (hhmm !== "") {
                /*console.log("01/01/2019 "+hhmm, (new Date("01/01/2019 "+hhmm)).getTime());*/
                return (new Date("01/01/2019 " + hhmm)).getTime();
            }
            else {
                var h = (new Date()).getHours();
                var m = (new Date()).getMinutes();
                /*console.log("01/01/2019 " + (h<10?"0"+h:h)+":"+(m<10?"0"+m:m) , (new Date("01/01/2019 " + (h<10?"0"+h:h)+":"+(m<10?"0"+m:m) )).getTime());*/
                return (new Date("01/01/2019 " + (h < 10 ? "0" + h : h) + ":" + (m < 10 ? "0" + m : m))).getTime();
            }
        };
        Extension.prototype.isScheduleOn = function (modeScheduleFrom, modeScheduleTo) {
            /*console.log(modeSchedule, modeScheduleFrom, modeScheduleTo);*/
            if (modeScheduleFrom !== "" && modeScheduleTo !== "") {
                /*24*60*60*1000*/
                var from = this.getTimeStamp(modeScheduleFrom);
                var to = this.getTimeStamp(modeScheduleTo);
                var cur = this.getTimeStamp("");
                if (from > to) {
                    to += (24 * 60 * 60 * 1000); /** add day in case of scenario like 10:00PM - 04:00AM */
                }
                console.log(cur, from, to, cur >= from, to >= cur);
                if (cur >= from && to >= cur) {
                    return true;
                }
                else {
                    return false;
                }
            }
        };
        Extension.prototype.toggleModeBasedOnSchedule = function (modeType, Off) {
            var config = this.config;
            if (modeType === "night") {
                console.log("Night ", config.nightMode, config.nightSchedule, config.nightScheduleFrom, config.nightScheduleTo);
                var scheduleOn = this.isScheduleOn(config.nightScheduleFrom, config.nightScheduleTo);
                if (Off && scheduleOn && config.nightMode === 1) {
                    console.log("changing nightMode to 0 from background");
                    config.nightMode = 0;
                }
                else if (!Off && scheduleOn && config.nightMode === 0) {
                    config.nightMode = 1;
                }
            }
            if (modeType === "dark") {
                console.log("Dark ", config.mode, config.modeSchedule, config.modeScheduleFrom, config.modeScheduleTo);
                var scheduleOn = this.isScheduleOn(config.modeScheduleFrom, config.modeScheduleTo);
                if (Off && scheduleOn && config.mode === 1) {
                    console.log("changing mode to 0 from background");
                    config.mode = 0;
                }
                else if (!Off && scheduleOn && config.mode === 0) {
                    config.mode = 1;
                }
            }
        };
        /**
         * Adds host name of last focused tab
         * into Sites List (or removes).
         */
        Extension.prototype.toggleCurrentSite = function (el) {
            var _this = this;
            this.getActiveTabInfo(function (info) {
                if (info.host) {
                    /*const index = this.config.siteList.indexOf(info.host);*/
                    var index = _this.config.blackList.indexOf(info.host);
                    /*console.log(toggleObj);*/
                    if (index < 0) {
                        /*this.config.siteList.push(info.host);*/
                        /*console.log("Off ",el!==null && el.element.elementOff.className.search("active")>-1)*/
                        if (el === null || (el !== null && el.element.elementOff.className.search("active") > -1)) {
                            _this.config.blackList.push(info.host);
                        }
                    }
                    else {
                        // Remove site from list
                        /*this.config.siteList.splice(index, 1);*/
                        /*console.log("On ",el!==null && el.element.elementOn.className.search("active")>-1);*/
                        if (el === null || (el !== null && el.element.elementOn.className.search("active") > -1)) {
                            _this.config.blackList.splice(index, 1);
                        }
                    }
                }
            });
        };
        //------------------------------------
        //
        //       Handle config changes
        //
        Extension.prototype.onAppToggle = function () {
            var _this = this;
            if (this.enabled) {
                //
                // Switch ON
                // Change icon
                chrome.browserAction.setIcon({
                    path: {
                        '19': ICON_PATHS.active_19,
                        '38': ICON_PATHS.active_38
                    }
                });
                // Subscribe to tab updates
                this.addTabListeners();
                // Set style for active tabs
                chrome.tabs.query({ active: true }, function (tabs) {
                    tabs.forEach(_this.addStyleToTab, _this);
                });
                // Update style for other tabs
                chrome.tabs.query({ active: false }, function (tabs) {
                    tabs.forEach(function (tab) {
                        setTimeout(function () { return _this.addStyleToTab(tab); }, 0);
                    });
                });
            }
            else {
                //
                // Switch OFF
                // Change icon
                chrome.browserAction.setIcon({
                    path: {
                        '19': ICON_PATHS.inactive_19,
                        '38': ICON_PATHS.inactive_38
                    }
                });
                // Unsubscribe from tab updates
                this.removeTabListeners();
                // Remove style from active tabs
                chrome.tabs.query({ active: true }, function (tabs) {
                    tabs.forEach(_this.removeStyleFromTab, _this);
                });
                // Remove style from other tabs
                chrome.tabs.query({ active: false }, function (tabs) {
                    tabs.forEach(function (tab) {
                        setTimeout(function () { return _this.removeStyleFromTab(tab); }, 0);
                    });
                });
            }
            /*this.toggleCurrentSite(null);*/
            this.saveUserSettings();
        };
        Extension.prototype.clearNightAlarms = function () {
            this.configCopy.nightSchedule = this.config.nightSchedule;
            chrome.alarms.clear(ALARMS.NightModeOff);
            chrome.alarms.clear(ALARMS.NightModeOn);
            this.removeAlarmListeners(ALARMS.NightModeOn);
        };
        Extension.prototype.clearDarkAlarms = function () {
            this.configCopy.modeSchedule = this.config.modeSchedule;
            chrome.alarms.clear(ALARMS.DarkModeOff);
            chrome.alarms.clear(ALARMS.DarkModeOn);
            this.removeAlarmListeners(ALARMS.DarkModeOn);
        };
        Extension.prototype.createAlarms = function () {
            if (this.config.nightSchedule === 0) {
                this.clearNightAlarms();
            }
            else if (this.config.nightSchedule === 1 && (this.config.nightSchedule !== this.configCopy.nightSchedule)) {
                /*                || this.config.nightScheduleFrom !== this.configCopy.nightScheduleFrom
                                || this.config.nightScheduleTo !== this.configCopy.nightScheduleTo)
                        ){*/
                this.clearNightAlarms();
                var hhmmFrom = this.config.nightScheduleFrom.split(":");
                var hhmmTo = this.config.nightScheduleTo.split(":");
                if (hhmmFrom.length === 2 && hhmmTo.length === 2) {
                    var fromWhen = (new Date());
                    fromWhen.setHours(Number(hhmmFrom[0]));
                    fromWhen.setMinutes(Number(hhmmFrom[1]));
                    chrome.alarms.create(ALARMS.NightModeOn, { when: fromWhen.getTime(), periodInMinutes: 1440 });
                    var toWhen = (new Date());
                    toWhen.setHours(Number(hhmmTo[0]));
                    toWhen.setMinutes(Number(hhmmTo[1]));
                    chrome.alarms.create(ALARMS.NightModeOff, { when: toWhen.getTime(), periodInMinutes: 1440 });
                    this.addAlarmListeners();
                }
            }
            /*if(this.config.modeSchedule !== this.configCopy.modeSchedule && this.config.modeSchedule === 0){*/
            if (this.config.modeSchedule === 0) {
                this.clearDarkAlarms();
            }
            else if (this.config.modeSchedule === 1 && (this.config.modeSchedule !== this.configCopy.modeSchedule)) {
                /*        || this.config.modeScheduleFrom !== this.configCopy.modeScheduleFrom
                        || this.config.modeScheduleTo !== this.configCopy.modeScheduleTo  )
                    ){*/
                this.clearDarkAlarms();
                var hhmmFrom = this.config.modeScheduleFrom.split(":");
                var hhmmTo = this.config.modeScheduleTo.split(":");
                if (hhmmFrom.length === 2 && hhmmTo.length === 2) {
                    var fromWhen = (new Date());
                    fromWhen.setHours(Number(hhmmFrom[0]));
                    fromWhen.setMinutes(Number(hhmmFrom[1]));
                    chrome.alarms.create(ALARMS.DarkModeOn, { when: fromWhen.getTime(), periodInMinutes: 1440 });
                    var toWhen = (new Date());
                    toWhen.setHours(Number(hhmmTo[0]));
                    toWhen.setMinutes(Number(hhmmTo[1]));
                    chrome.alarms.create(ALARMS.DarkModeOff, { when: toWhen.getTime(), periodInMinutes: 1440 });
                    this.addAlarmListeners();
                    console.log("modeSchedule times ", fromWhen, toWhen);
                }
            }
            /*chrome.alarms.getAll(function(alarms){
                for(var i=0; i<alarms.length; i++){
                    var alarm = alarms[i];
                    if(alarm.name === ALARMS.DarkModeOn){
                        console.log("DarkModeOn enabled ", alarm);
                    }
                   if(alarm.name === ALARMS.DarkModeOff){
                    console.log("DarkModeOff enabled", alarm);
                    }
                    if(alarm.name === ALARMS.NightModeOn){
                        console.log("NightModeOn enabled", alarm);
                    }
                    if(alarm.name === ALARMS.NightModeOff){
                        console.log("NightModeOff enabled", alarm);
                    }
                }
            });*/
        };
        Extension.prototype.onConfigPropChanged = function () {
            var _this = this;
            /*console.log("onConfigPropChanged ");*/
            if (this.enabled) {
                this.createAlarms();
                // Update style for active tabs
                chrome.tabs.query({ active: true }, function (tabs) {
                    tabs.forEach(_this.addStyleToTab, _this);
                });
                // Update style for other tabs
                chrome.tabs.query({ active: false }, function (tabs) {
                    tabs.forEach(function (tab) {
                        setTimeout(function () { return _this.addStyleToTab(tab); }, 0);
                    });
                });
            }
            this.saveUserSettings();
        };
        //-------------------------
        //
        // Working with chrome tabs
        //
        //-------------------------
        Extension.prototype.addTabListeners = function () {
            if (!chrome.tabs.onUpdated.hasListener(this.tabUpdateListener)) {
                chrome.tabs.onUpdated.addListener(this.tabUpdateListener);
            }
            // Replace fires instead of update when page loaded from cache
            // https://bugs.chromium.org/p/chromium/issues/detail?id=109557
            // https://bugs.chromium.org/p/chromium/issues/detail?id=116379
            if (!chrome.tabs.onReplaced.hasListener(this.tabReplaceListener)) {
                chrome.tabs.onReplaced.addListener(this.tabReplaceListener);
            }
        };
        Extension.prototype.removeTabListeners = function () {
            chrome.tabs.onUpdated.removeListener(this.tabUpdateListener);
            chrome.tabs.onReplaced.removeListener(this.tabReplaceListener);
        };
        //----------------------
        //
        // Add/remove css to tab
        //
        //----------------------
        Extension.prototype.canInjectScript = function (tab) {
            // Prevent throwing errors on specific chrome adresses
            return (tab && canInjectScript(tab.url));
        };
        /**
         * Adds style to tab.
         */
        Extension.prototype.addStyleToTab = function (tab) {
            if (!this.canInjectScript(tab)) {
                return;
            }
            chrome.tabs.executeScript(tab.id, {
                code: this.getCode_addStyle(tab.url),
                runAt: 'document_start'
            });
        };
        /**
         * Removes style from tab.
         */
        Extension.prototype.removeStyleFromTab = function (tab) {
            if (!this.canInjectScript(tab)) {
                return;
            }
            chrome.tabs.executeScript(tab.id, {
                code: this.getCode_removeStyle()
            });
        };
        Extension.prototype.getCode_addStyle = function (url) {
            var css = this.generator.createCssCode(this.config, url);
            var createShader = this.generator.createShader(this.config, url);
            return "(function () {\n" + (DarkReader.DEBUG ? "console.log('Executing DR script (add)...');" : "") + "\nvar createDRStyle = function() {\n    createShader();\n    var css = '" + css.replace(/'/g, '\\\'') + "';\n    var style = document.createElement('style');\n    style.setAttribute('id', 'dark-reader-style');\n    style.type = 'text/css';\n    style.appendChild(document.createTextNode(css));\n    return style;\n};\nvar createShader = function(){\n    " + (createShader ? "var ss = document.getElementById('screen-shader');if(ss===null){var div = document.createElement('div');div.id='screen-shader';div.classList.add('on');document.getElementsByTagName('body')[0].appendChild(div);}else{ss.classList.add('on');ss.classList.remove('off');}" : "var ss = document.getElementById('screen-shader');if(ss!==null){ss.classList.remove('on');ss.classList.add('off');}") + "\n};\nif (document.head) {\n    var style = createDRStyle();\n    var prevStyle = document.getElementById('dark-reader-style');\n    if (!prevStyle) {\n        document.head.appendChild(style);\n        " + (DarkReader.DEBUG ? "console.log('Added DR style.');" : "") + "\n    } else if (style.textContent.replace(/^\\s*/gm, '') !== prevStyle.textContent.replace(/^\\s*/gm, '')) {\n        prevStyle.parentElement.removeChild(prevStyle);\n        document.head.appendChild(style);\n        " + (DarkReader.DEBUG ? "console.log('Updated DR style.');" : "") + "\n    }\n} else {\n    var drObserver = new MutationObserver(function (mutations) {\n        for (var i = 0; i < mutations.length; i++) {\n            if (mutations[i].target.nodeName === 'HEAD') {\n                drObserver.disconnect();\n                document.removeEventListener('readystatechange', onReady);\n                var prevStyle = document.getElementById('dark-reader-style');\n                if (!prevStyle) {\n                    var style = createDRStyle();\n                    document.head.appendChild(style);\n                    " + (DarkReader.DEBUG ? "console.log('Added DR style using observer.');" : "") + "\n                }\n                break;\n            }\n        }\n    });\n    drObserver.observe(document, { childList: true, subtree: true });\n    var onReady = function() {\n        if (document.readyState !== 'complete') { \n            return;\n        }\n        drObserver.disconnect();\n        document.removeEventListener('readystatechange', onReady);\n        if (!document.head) {\n            var head = document.createElement('head');\n            document.documentElement.insertBefore(head, document.documentElement.firstElementChild);\n        }\n        var prevStyle = document.getElementById('dark-reader-style');\n        if (!prevStyle) {\n            var style = createDRStyle();\n            document.head.appendChild(style);\n            " + (DarkReader.DEBUG ? "console.log('Added DR style on document ready.');" : "") + "\n        }\n    };\n    document.addEventListener('readystatechange', onReady);\n    if (document.readyState === 'complete') { \n        onReady();\n    }\n}\n})()";
        };
        Extension.prototype.getCode_removeStyle = function () {
            return "(function () {\n" + (DarkReader.DEBUG ? "console.log('Executing DR script (remove)...');" : "") + "\nvar style = document.getElementById('dark-reader-style');\nstyle && style.parentElement.removeChild(style);\n})();";
        };
        //-------------------------------------
        //
        //       Configuration management
        //
        //-------------------------------------
        /**
         * Loads configuration from Chrome storage.
         */
        Extension.prototype.loadUserSettings = function () {
            var _this = this;
            var defaultFilterConfig = xp.clone(DarkReader.DEFAULT_FILTER_CONFIG);
            var defaultStore = {
                enabled: true,
                config: defaultFilterConfig,
                configCopy: defaultFilterConfig,
                installedTimestamp: 0,
                popupOpenCount: 0
            };
            /*console.log("loadUserSettings ", defaultStore);*/
            chrome.storage.sync.get(defaultStore, function (store) {
                if (!store.config) {
                    store.config = defaultFilterConfig;
                }
                if (!store.configCopy) {
                    store.configCopy = defaultFilterConfig;
                }
                if (!Array.isArray(store.config.siteList)) {
                    var arr = [];
                    for (var key in store.config.siteList) {
                        arr[key] = store.config.siteList[key];
                    }
                    store.config.siteList = arr;
                }
                if (!Array.isArray(store.config.blackList)) {
                    var arr = [];
                    for (var key in store.config.blackList) {
                        arr[key] = store.config.blackList[key];
                    }
                    store.config.blackList = arr;
                }
                if (!Array.isArray(store.config.whiteList)) {
                    var arr = [];
                    for (var key in store.config.whiteList) {
                        arr[key] = store.config.whiteList[key];
                    }
                    store.config.whiteList = arr;
                }
                _this.config = xp.observable(store.config);
                /*this.configCopy = <ObservableFilterConfig>xp.observable(store.config);*/
                _this.configCopy = Object["assign"]({}, _this.config);
                _this.enabled = store.enabled;
                _this.installedTimestamp = store.installedTimestamp;
                _this.popupOpenCount = store.popupOpenCount;
                console.log('loaded', store);
            });
        };
        /**
         * Saves configuration to Chrome storage.
         */
        Extension.prototype.saveUserSettings = function () {
            var _this = this;
            // NOTE: Debounce config saving.
            if (this.savedTimeout) {
                clearTimeout(this.savedTimeout);
            }
            this.savedTimeout = setTimeout(function () {
                var store = {
                    enabled: _this.enabled,
                    config: _this.config,
                    configCopy: _this.config,
                    popupOpenCount: _this.popupOpenCount,
                    installedTimestamp: _this.installedTimestamp
                };
                chrome.storage.sync.set(store, function () {
                    console.log('saved', store);
                    _this.savedTimeout = null;
                });
            }, SAVE_CONFIG_TIMEOUT);
        };
        Extension.prototype.resetToDefault = function () {
            var defaultFilterConfig = xp.clone(DarkReader.DEFAULT_FILTER_CONFIG);
            defaultFilterConfig.mode = this.config.mode;
            defaultFilterConfig.nightMode = this.config.nightMode;
            defaultFilterConfig.modeSchedule = this.config.modeSchedule;
            defaultFilterConfig.modeScheduleFrom = this.config.modeScheduleFrom;
            defaultFilterConfig.modeScheduleTo = this.config.modeScheduleTo;
            defaultFilterConfig.nightSchedule = this.config.nightSchedule;
            defaultFilterConfig.nightScheduleFrom = this.config.nightScheduleFrom;
            defaultFilterConfig.nightScheduleTo = this.config.nightScheduleTo;
            this.config = xp.observable(defaultFilterConfig);
            this.configCopy = defaultFilterConfig;
            this.saveUserSettings();
        };
        /**
         * Returns the list of fonts
         * installed in system.
         */
        Extension.prototype.getFontList = function (onReturned) {
            if (!chrome.fontSettings) {
                // Todo: Remove it as soon as Firefox and Edge get support.
                setTimeout(function () { return onReturned([
                    'serif',
                    'sans-serif',
                    'monospace',
                    'cursive',
                    'fantasy',
                    'system-ui'
                ]); });
                return;
            }
            chrome.fontSettings.getFontList(function (res) {
                // id or name?
                var fonts = res.map(function (r) { return r.fontId; });
                onReturned(fonts);
            });
        };
        //-------------------------------------
        //
        //          Developer tools
        //
        //-------------------------------------
        Extension.prototype.getSavedDevInversionFixes = function () {
            return localStorage.getItem('dev_inversion_fixes') || null;
        };
        Extension.prototype.saveDevInversionFixes = function (json) {
            localStorage.setItem('dev_inversion_fixes', json);
        };
        Extension.prototype.getDevInversionFixesText = function () {
            var fixes = this.getSavedDevInversionFixes();
            return DarkReader.formatJson(fixes ? JSON.parse(fixes) : DarkReader.copyJson(DarkReader.RAW_INVERSION_FIXES));
        };
        Extension.prototype.resetDevInversionFixes = function () {
            localStorage.removeItem('dev_inversion_fixes');
            DarkReader.handleInversionFixes(DarkReader.copyJson(DarkReader.RAW_INVERSION_FIXES));
            this.onConfigPropChanged();
        };
        Extension.prototype.applyDevInversionFixes = function (json, callback) {
            var obj;
            try {
                obj = JSON.parse(json);
                var text = DarkReader.formatJson(obj);
                this.saveDevInversionFixes(text);
                DarkReader.handleInversionFixes(obj);
                this.onConfigPropChanged();
                callback(null);
            }
            catch (err) {
                callback(err);
            }
        };
        return Extension;
    })(xp.Model);
    DarkReader.Extension = Extension;
    function canInjectScript(url) {
        return url
            && url.indexOf('chrome') !== 0
            && url.indexOf('https://chrome.google.com/webstore') !== 0
            && url.indexOf('about:') !== 0
            && url.indexOf('view-source:') !== 0
            && url.indexOf('https://addons.mozilla.org') !== 0;
    }
})(DarkReader || (DarkReader = {}));
