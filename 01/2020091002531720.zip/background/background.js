var DarkReader;
(function (DarkReader) {
    var Background;
    (function (Background) {
        // Initialize extension
        Background.extension;
        Background.onExtensionLoaded = new xp.Event();
        chrome.runtime.onInstalled.addListener(function (o) {
            /*console.log("extension installed ", o.reason);*/
            /*_self.config.installedTimestamp = (new Date()).getTime();
            _self.config.popupOpenCount = 0;*/
            if (o.reason === "install") {
                chrome.tabs.create({
                    url: 'https://lunarreader.com/',
                    active: true
                });
            }
            chrome.storage.sync.set({ installedTimestamp: (new Date()).getTime(), popupOpenCount: 0 }, function () {
                console.log('installedTimestamp is set to ' + (new Date()).getTime());
            });
        });
        DarkReader.loadConfigs(function () {
            /*console.log("loadConfigs cb");*/
            Background.extension = new DarkReader.Extension(new DarkReader.FilterCssGenerator());
            /*console.log(extension);*/
            Background.onExtensionLoaded.invoke(Background.extension);
        });
        /*
        if (DarkReader.DEBUG) {
            // Reload extension on connection
            var listen = function () {
                var req = new XMLHttpRequest();
                req.open('GET', 'http://localhost:8890/', true);
                req.onload = function () {
                    if (req.status >= 200 && req.status < 300) {
                        chrome.runtime.reload();
                    }
                    else {
                        setTimeout(listen, 2000);
                    }
                };
                req.onerror = function () { return setTimeout(listen, 2000); };
                req.send();
            };
            setTimeout(listen, 2000);
        }
        */
    })(Background = DarkReader.Background || (DarkReader.Background = {}));
})(DarkReader || (DarkReader = {}));
