var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var DarkReader;
(function (DarkReader) {
    var Popup;
    (function (Popup) {
        // TODO: Grid cells behaviour.
        /**
         * Site list.
         */
        var SiteList = (function (_super) {
            __extends(SiteList, _super);
            function SiteList(markup) {
                _super.call(this, markup);
                // Add one extra Text box
                this.addTextBox('', void (0), true);
                this.addClearButton();
            }
            SiteList.prototype.getTemplate = function () {
                var t = _super.prototype.getTemplate.call(this);
                t.classList.add('SiteList');
                return t;
            };
            SiteList.prototype.defineProperties = function () {
                var _this = this;
                _super.prototype.defineProperties.call(this);
                /*console.log(this.sites);*/
                this.sitesChangeRegistrar = new xp.EventRegistrar();
                this.defineProperty('sites', {
                    setter: function (sites) {
                        _this.sitesChangeRegistrar.unsubscribeAll();
                        /*console.log(sites);*/
                        if (!sites) {
                            return;
                        }
                        _this.sitesChangeRegistrar.subscribe(sites.onCollectionChanged, function (args) {
                            switch (args.action) {
                                case xp.CollectionChangeAction.Create:
                                    _this.addTextBox(args.newItem, args.newIndex);
                                    break;
                                case xp.CollectionChangeAction.Delete:
                                    _this.removeTextBox(args.oldIndex);
                                    break;
                                /*case xp.CollectionChangeAction.Replace:
                                    this.children[args.newIndex].children[0].text = args.newItem;
                                    break;*/
                                default:
                                    throw new Error('Not implemented.');
                            }
                        });
                        /*console.log(sites);*/
                        sites.forEach(function (s, i) { return _this.addTextBox(s, i); });
                    }
                });
            };
            SiteList.prototype.addTextBox = function (site, index, isExtraTextBox) {
                var _this = this;
                /*console.log(site, index, isExtraTextBox);*/
                var textBox = new xp.TextBox({
                    text: site,
                    style: 'siteListTextBox',
                    //placeholder: 'mail.google.com, google.*/mail etc...',
                    placeholder: 'Enter site here...',
                    readonly: !isExtraTextBox,
                    onTextChange: function (e) {
                        /*console.log(this.children, textBox, this.sites);*/
                        /*const i = this.children.indexOf(textBox);*/
                        var value = e.newText.trim();
                        var isValueValid = !!value.match(/^([^\.\s]+?\.?)+$/);
                        if (isExtraTextBox) {
                            if (isValueValid) {
                                // Add new site
                                if (_this.sites.indexOf(value) === -1) {
                                    _this.sites.push(value);
                                    textBox.text = '';
                                    _this.focus();
                                }
                            }
                        }
                        else {
                        }
                    },
                });
                if (index === void (0)) {
                    index = this.children.length;
                }
                var closeBtn = new xp.Button({
                    style: 'iconButton closeIconButton' + (isExtraTextBox ? " hideCloseIcon" : ""),
                    icon: '.closeIcon',
                    onClick: function () {
                        /*console.log(index, this.sites, site);*/
                        _this.sites.splice(_this.sites.indexOf(site), 1);
                        /*this.removeTextBox(index);*/
                    }
                });
                var hBox;
                if (isExtraTextBox) {
                    var addBtn = new xp.Button({
                        style: 'siteAddButton',
                        text: 'Add',
                        onClick: function (e) {
                            /*console.log(index);
                            let el = document.getElementsByClassName("siteListTextBox")[0];
                            console.log(el);
                            el["value"] = "";
                            /*const isValueValid = !!value.match(/^([^\.\s]+?\.?)+$/);
                            if (isValueValid) {
                                // Add new site
                                this.sites.push(value);
                                textBox.text = '';
                                this.focus();
                            }*/
                            /*this.removeTextBox(index);*/
                        }
                    });
                    hBox = new xp.HBox({ style: 'line siteListItemWrap siteListItemWrap-Last' }, [textBox, addBtn]);
                }
                else {
                    hBox = new xp.HBox({ style: 'line siteListItemWrap' }, [textBox, closeBtn]);
                }
                /*this.insert(textBox, index);*/
                this.insert(hBox, index);
            };
            SiteList.prototype.removeTextBox = function (index) {
                var textBox = this.children[index];
                textBox.remove();
            };
            SiteList.prototype.addClearButton = function () {
                var _this = this;
                var _self = this;
                var clearBtn = new xp.VBox({ style: 'confirm_clear_wrap', flex: 'none' }, [
                    new xp.VBox({ style: 'confirm_box', flex: 'none', init: function (el) { return _this.confirmBox = el; } }, [
                        new xp.HBox({ style: 'confirm_heading', flex: 'none' }, [
                            new xp.Label({
                                text: 'ALERT !',
                            }),
                        ]),
                        new xp.HBox({ style: 'confirm_text', flex: 'none' }, [
                            new xp.Label({
                                text: 'Do you want to clear all website from the list?',
                            }),
                        ]),
                        new xp.HBox({ style: 'confirm_btn_wrap', flex: 'none' }, [
                            new xp.Button({
                                style: 'confirm_yes',
                                text: 'Yes',
                                onClick: function () {
                                    var l = _self.sites.length;
                                    for (var i = 0; i < l; i++) {
                                        _self.sites.pop();
                                    }
                                    /*document.getElementsByClassName("confirm_box")[0]["style"].display = "none";*/
                                    /*console.log(_self.confirmBox);*/
                                    _self.confirmBox.domElement["style"].display = "none";
                                }
                            }),
                            new xp.Button({
                                style: 'confirm_no',
                                text: 'No',
                                onClick: function () {
                                    /* document.getElementsByClassName("confirm_box")[0]["style"].display = "none";*/
                                    /*console.log(_self.confirmBox);*/
                                    _self.confirmBox.domElement["style"].display = "none";
                                }
                            })
                        ]),
                    ]),
                    new xp.Button({
                        style: 'clearListBtn',
                        text: 'Clear List',
                        onClick: function () {
                            /*document.getElementsByClassName("confirm_box")[0]["style"].display = "block";*/
                            _self.confirmBox.domElement["style"].display = "block";
                            /*console.log(_self.confirmBox);*/
                            /*let l = _self.sites.length;
                            for(let i=0; i<l; i++){
                                _self.sites.pop();
                            }*/
                            /*_self.sites.splice(0);*/
                        }
                    }),
                ]);
                var hBox = new xp.HBox({ style: 'line clearListWrap' }, [clearBtn]);
                var index = this.children.length;
                this.insert(hBox, index);
            };
            /**
             * Sets focus to the last extra text box.
             */
            SiteList.prototype.focus = function () {
                /*console.log(this.sites);*/
                this.children[this.children.length - 1].focus();
                var container = this.parent.domElement;
                container.scrollTop = container.scrollHeight;
                /*console.log(this.sites);*/
            };
            return SiteList;
        })(xp.VBox);
        Popup.SiteList = SiteList;
    })(Popup = DarkReader.Popup || (DarkReader.Popup = {}));
})(DarkReader || (DarkReader = {}));
