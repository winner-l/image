var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var DarkReader;
(function (DarkReader) {
    var Popup;
    (function (Popup) {
        var PopupWindow = (function (_super) {
            __extends(PopupWindow, _super);
            function PopupWindow(ext) {
                var _this = this;
                _super.call(this, { title: 'Lunar Reader settings', scope: ext, scrollBar: 'none' }, [
                    //
                    // ---- Logo ----
                    new xp.Html({
                        html: {
                            tag: 'img',
                            /*attrs: { id: 'logo', src: 'img/dark-reader-type.svg', alt: 'Dark Reader' }*/
                            attrs: { id: 'logo', src: 'img/cropped-LunarReader-Google-Blue-Logo.png', alt: 'Lunar Reader' }
                        },
                        flex: 'none'
                    }),
                    new xp.Button({
                        style: 'iconButton settingsButton',
                        icon: '.gearIcon',
                        onClick: function (el) {
                            /*console.log(el);*/
                            document.getElementsByClassName('settings_wrap')[0]['style']['display'] = 'block';
                        }
                    }),
                    new xp.VBox({ style: 'settings_wrap', flex: 'none' }, [
                        new xp.VBox({ style: 'settings_box', flex: 'none' }, [
                            new xp.Button({
                                style: 'iconButton settings_close',
                                icon: '.settingsCloseIcon',
                                onClick: function () {
                                    document.getElementsByClassName('settings_wrap')[0]['style']['display'] = 'none';
                                }
                            }),
                            new xp.Html({
                                html: {
                                    tag: 'a',
                                    attrs: { id: 'tutorial_link', class: 'settings_links', href: 'https://lunarreader.com/how-to-use/', alt: 'Tutorial', target: '_newtab' },
                                    children: ['Tutorial']
                                },
                                flex: 'none'
                            }),
                            new xp.Html({
                                html: {
                                    tag: 'a',
                                    attrs: { id: 'faq_link', class: 'settings_links', href: 'https://lunarreader.com/faq/', alt: 'FAQ', target: '_newtab' },
                                    children: ['FAQ']
                                },
                                flex: 'none'
                            }),
                            new xp.Html({
                                html: {
                                    tag: 'a',
                                    attrs: { id: 'feedback_link', class: 'settings_links', href: 'https://lunarreader.com/contact-us/', alt: 'Feedback', target: '_newtab' },
                                    children: ['Feedback']
                                },
                                flex: 'none'
                            }),
                            new xp.Html({
                                html: { tag: 'div', attrs: { class: "seperator" } },
                                flex: 'none'
                            }),
                            new xp.Html({
                                html: { tag: 'div', attrs: { class: 'shortcutHeading' }, children: ['Shortcuts'] },
                                flex: 'none'
                            }),
                            new xp.HBox({ style: 'command_wrap', flex: 'none' }, [
                                new xp.Label({
                                    text: 'Extension On/Off',
                                }),
                                new Popup.HotkeyLink({
                                    commandName: 'toggle',
                                    noHotkeyText: 'Alt+Shift+E',
                                    /*noHotkeyText: 'Setup Shortcut',*/
                                    hotkeyTextTemplate: '\n#HOTKEY',
                                    style: 'status'
                                })
                            ]),
                            new xp.HBox({ style: 'command_wrap', flex: 'none' }, [
                                new xp.Label({
                                    text: 'Dark Mode On/Off',
                                }),
                                new Popup.HotkeyLink({
                                    commandName: 'darkModeToggle',
                                    noHotkeyText: 'Alt+Shift+D',
                                    /*noHotkeyText: 'Setup Shortcut',*/
                                    hotkeyTextTemplate: '\n#HOTKEY',
                                    style: 'status'
                                })
                            ]),
                            new xp.HBox({ style: 'command_wrap', flex: 'none' }, [
                                new xp.Label({
                                    text: 'Night Shift On/Off',
                                }),
                                new Popup.HotkeyLink({
                                    commandName: 'nightModeToggle',
                                    noHotkeyText: 'Alt+Shift+S',
                                    /*noHotkeyText: 'Setup Shortcut',*/
                                    hotkeyTextTemplate: '\n#HOTKEY',
                                    style: 'status'
                                })
                            ]),
                            new xp.Html({
                                html: {
                                    tag: 'div',
                                    attrs: { class: "seperator" }
                                },
                                flex: 'none'
                            }),
                            new xp.HBox({ style: 'settings_bottom_links', flex: 'none' }, [
                                new xp.Button({
                                    style: 'settings_btn_links rateNowBtnBlue',
                                    text: 'Rate',
                                    onClick: function () {
                                        document.getElementsByClassName("rateConfirmClearWrap")[0]["style"].display = "block";
                                    }
                                }),
                                new xp.Html({
                                    html: {
                                        tag: 'a',
                                        attrs: { class: 'settings_btn_links', href: 'https://lunarreader.com/about-us/', alt: 'About Us', target: '_newtab' },
                                        children: ['About Us']
                                    },
                                    flex: 'none'
                                }),
                                new xp.Html({
                                    html: {
                                        tag: 'a',
                                        attrs: { class: 'settings_btn_links', href: 'https://lunarreader.com/privacy/', alt: 'Privacy', target: '_newtab' },
                                        children: ['Privacy']
                                    },
                                    flex: 'none'
                                }),
                            ]),
                        ]),
                    ]),
                    //
                    // ---- Top section ----
                    new xp.HBox({ name: 'topSection', itemsAlign: 'top', flex: 'none' }, [
                        // new xp.Label({
                        //     name: 'appDescription',
                        //     style: 'description',
                        //     text: 'Adjust settings that\nbetter fit your screen'
                        // }),
                        new xp.HBox({ flex: 'none', style: 'line controlContainer powerIconWrap' }, [
                            /*new Toggle({
                                value: '{enabled}',
                                labelOn: '',
                                labelOff: '',
                            }),*/
                            new xp.ToggleButton({
                                style: 'iconButton powerOnIcon',
                                icon: '.extEnabled',
                                item: false,
                                selectedItem: '{enabled}',
                                onCheckChange: function (e) {
                                    /*console.log(e, ext.enabled);
                                    console.log(this.siteToggle2, this.currentSiteName.domElement.textContent);*/
                                    _this.siteToggle2.value = (ext.enabled && ext.config.blackList.indexOf(_this.currentSiteName.domElement.textContent) < 0) ? 1 : 0;
                                },
                            }),
                            new xp.ToggleButton({
                                style: 'iconButton powerOffIcon',
                                icon: '.extEnabled',
                                item: true,
                                selectedItem: '{enabled}',
                                onCheckChange: function (e) {
                                    /*console.log(e, ext.enabled);
                                    console.log(this.siteToggle2, this.currentSiteName.domElement.textContent);*/
                                    _this.siteToggle2.value = (ext.enabled && ext.config.blackList.indexOf(_this.currentSiteName.domElement.textContent) < 0) ? 1 : 0;
                                },
                            }),
                        ])
                    ]),
                    new xp.Label({
                        text: 'Auto added to Blacklist',
                        name: 'autoAddMsg',
                        flex: 'none',
                    }),
                    new xp.Label({
                        text: 'Removed from Blacklist',
                        name: 'autoRemoveMsg',
                        flex: 'none',
                    }),
                    new xp.VBox({ name: 'siteToggleWrap', style: 'controlContainer modeToggleContainer', enabled: '{enabled}' }, [
                        new xp.HBox({ style: 'line' }, [
                            new xp.Label({
                                text: '',
                                name: 'currentSiteName',
                                flex: 'none',
                            }),
                            new Popup.Toggle({
                                /*value: '{enabled}',*/
                                name: 'siteToggle2',
                                valueOn: 1,
                                valueOff: 0,
                                labelOn: '',
                                labelOff: '',
                                flex: 'stretch',
                                onClick: function (el) {
                                    var eOn, eOff;
                                    if (el.domEvent.target.parentElement['className'].search("switchedOn") === -1) {
                                        eOn = document.getElementById("autoAddMsg");
                                        eOff = document.getElementById("autoRemoveMsg");
                                    }
                                    else {
                                        eOn = document.getElementById("autoRemoveMsg");
                                        eOff = document.getElementById("autoAddMsg");
                                    }
                                    var cOn = eOn.className;
                                    var cOff = eOff.className;
                                    if (cOn.search("showAutoAddMsg") === -1) {
                                        eOn.className = eOn.className + " showAutoAddMsg";
                                        eOff.className = eOff.className.replace(/showAutoAddMsg/g, "");
                                        setTimeout(function () {
                                            eOn.className = cOn;
                                        }, 3000);
                                    }
                                    ext.toggleCurrentSite(el);
                                }
                            }),
                        ]),
                    ]),
                    /*new xp.HBox({ name: 'topSection2', style: 'line', flex: 'none' }, [
                        new xp.VBox({ flex: 'stretch', style: 'controlContainer siteToggleContainer' }, [
                            new xp.Button({
                                name: 'siteToggle',
                                onClick: () => {
                                    ext.toggleCurrentSite();
                                }
                            }),
                            new HotkeyLink({
                                commandName: 'addSite',
                                noHotkeyText: 'setup current site\ntoggle hotkey',
                                hotkeyTextTemplate: 'toggle current site\n#HOTKEY',
                                style: 'status',
                                enabled: '{enabled}'
                            }),
                        ])
                    ]),*/
                    //
                    // ---- Tab panel ----
                    new Popup.TabPanel({ onTabSwitched: function (t) { }, flex: 'stretch', enabled: '{enabled}' }, [
                        //
                        // ---- Filter ----
                        new Popup.Tab({ tabName: 'General', itemsAlign: 'stretch' }, [
                            // Mode
                            new xp.VBox({ name: 'modeToggle', style: 'controlContainer modeToggleContainer' }, [
                                new xp.HBox({ style: 'line' }, [
                                    /*new xp.ToggleButton({
                                        style: 'iconButton',
                                        icon: '.darkMode',
                                        item: 1/*FilterMode.dark* /,
                                        selectedItem: '{config.mode}'
                                    }),*/
                                    new xp.Label({
                                        text: 'DARK MODE',
                                        flex: 'none',
                                    }),
                                    new xp.Label({
                                        text: '',
                                        flex: 'none',
                                        name: 'modeOnUntil',
                                    }),
                                    new Popup.Toggle({
                                        value: '{config.mode}',
                                        valueOn: 1,
                                        valueOff: 0,
                                        labelOn: '',
                                        labelOff: '',
                                        flex: 'stretch',
                                        onClick: function (el) {
                                            if (el.element["elementOff"].className.search("active") > -1) {
                                                if (ext.config.modeSchedule === 1) {
                                                    ext.config.modeSchedule = 0;
                                                    _this.showHideOnUntilLabel(ext, "dark");
                                                    _this.setDarkScheduleState();
                                                }
                                            }
                                        }
                                    }),
                                ]),
                            ]),
                            // Test
                            new Popup.Range({
                                label: 'Brightness',
                                step: 0.1,
                                value: '{config.brightness}',
                                setterConvertor: function (v) { return (v - 50) / 100; },
                                getterConvertor: function (v) { return Math.round(v * 100) + 50; },
                                statusCreator: function (v) { return v > 100 ?
                                    '+' + (v - 100)
                                    : v < 100 ?
                                        '-' + (100 - v)
                                        : '0'; }
                            }),
                            // Brightness
                            /*new UpDown({
                                label: 'Brightness',
                                step: 0.1,
                                value: '{config.brightness}',
                                setterConvertor: (v: number) => (v - 50) / 100,
                                getterConvertor: (v: number) => Math.round(v * 100) + 50,
                                statusCreator: (v: number) => v > 100 ?
                                    '+' + (v - 100)
                                    : v < 100 ?
                                        '-' + (100 - v)
                                        : '0'
                            }),*/
                            new Popup.Range({
                                label: 'Contrast',
                                step: 0.1,
                                value: '{config.contrast}',
                                setterConvertor: function (v) { return (v - 50) / 100; },
                                getterConvertor: function (v) { return Math.round(v * 100) + 50; },
                                statusCreator: function (v) { return v > 100 ?
                                    '+' + (v - 100)
                                    : v < 100 ?
                                        '-' + (100 - v)
                                        : '0'; }
                            }),
                            // Contrast
                            /*new UpDown({
                                label: 'Contrast',
                                step: 0.1,
                                value: '{config.contrast}',
                                setterConvertor: (v: number) => (v - 50) / 100,
                                getterConvertor: (v: number) => Math.round(v * 100) + 50,
                                statusCreator: (v: number) => v > 100 ?
                                    '+' + (v - 100)
                                    : v < 100 ?
                                        '-' + (100 - v)
                                        : '0'
                            }),*/
                            /*new Range({
                                label: 'Saturation',
                                step: 0.1,
                                value: '{config.saturation}',
                                setterConvertor: (v: number) => v / 200,
                                getterConvertor: (v: number) => Math.round(v * 200),
                                statusCreator: (v: number) => v > 0 ?
                                    v + '%'
                                    : 'off'
                            }),*/
                            new Popup.Range({
                                label: 'Grayscale',
                                step: 0.1,
                                value: '{config.grayscale}',
                                setterConvertor: function (v) { return v / 100; },
                                getterConvertor: function (v) { return Math.round(v * 100); },
                                statusCreator: function (v) { return v > 0 ?
                                    '+' + v
                                    : '0'; }
                            }),
                            // Grayscale
                            /*new UpDown({
                                label: 'Grayscale',
                                step: 0.1,
                                value: '{config.grayscale}',
                                setterConvertor: (v: number) => v / 100,
                                getterConvertor: (v: number) => Math.round(v * 100),
                                statusCreator: (v: number) => v > 0 ?
                                    '+' + v
                                    : '0'
                            }),*/
                            /*new Range({
                                label: 'Sepia',
                                step: 0.1,
                                value: '{config.sepia}',
                                setterConvertor: (v: number) => v / 100,
                                getterConvertor: (v: number) => Math.round(v * 100),
                                statusCreator: (v: number) => v > 0 ?
                                    '+' + v
                                    : '0'
                            }),*/
                            // Sepia
                            /*new UpDown({
                                label: 'Sepia',
                                step: 0.1,
                                value: '{config.sepia}',
                                setterConvertor: (v: number) => v / 100,
                                getterConvertor: (v: number) => Math.round(v * 100),
                                statusCreator: (v: number) => v > 0 ?
                                    '+' + v
                                    : '0'
                            }),*/
                            new xp.VBox({ name: 'nightModeToggle', style: 'controlContainer modeToggleContainer' }, [
                                new xp.HBox({ style: 'line' }, [
                                    /*new xp.ToggleButton({
                                        style: 'iconButton',
                                        icon: '.darkMode',
                                        item: 1/*FilterMode.dark* /,
                                        selectedItem: '{config.mode}'
                                    }),*/
                                    new xp.Label({
                                        text: 'NIGHT SHIFT',
                                        flex: 'none',
                                    }),
                                    new xp.Label({
                                        text: '',
                                        flex: 'none',
                                        name: 'nightOnUntil',
                                    }),
                                    new Popup.Toggle({
                                        value: '{config.nightMode}',
                                        valueOn: 1,
                                        valueOff: 0,
                                        labelOn: '',
                                        labelOff: '',
                                        flex: 'grow',
                                        onClick: function (el) {
                                            if (el.element["elementOff"].className.search("active") > -1) {
                                                if (ext.config.nightSchedule === 1) {
                                                    ext.config.nightSchedule = 0;
                                                    _this.showHideOnUntilLabel(ext, "night");
                                                    _this.setNightScheduleState();
                                                }
                                            }
                                        }
                                    }),
                                ]),
                            ]),
                            new Popup.Range({
                                label: 'Color Temperature',
                                step: 0.1,
                                value: '{config.warm}',
                                bottomLeftLabel: "Less warm",
                                bottomRightLabel: "More warm",
                                style: "colorTempRange",
                                setterConvertor: function (v) { return v / 100; },
                                getterConvertor: function (v) { return Math.round(v * 100); },
                                statusCreator: function (v) { return v > 0 ?
                                    v + '%'
                                    : 'off'; }
                            }),
                            new xp.Label({ style: 'status nightShiftWarning', text: 'Notice: Night Shift may affect computer\'s performance' }),
                            new xp.Button({
                                style: 'resetToDefaultBtn',
                                text: 'Default',
                                onClick: function () {
                                    ext.resetToDefault();
                                    /*document.getElementsByClassName("confirm_box")[0]["style"].display = "block";*/
                                    /*_self.confirmBox.domElement["style"].display = "block";*/
                                    /*console.log(_self.confirmBox);*/
                                    /*let l = _self.sites.length;
                                    for(let i=0; i<l; i++){
                                        _self.sites.pop();
                                    }*/
                                    /*_self.sites.splice(0);*/
                                }
                            }),
                        ]),
                        //
                        // ---- Font ----
                        /*new Tab({ tabName: 'Font' }, [
                            // Select font
                            new xp.VBox({ style: 'controlContainer' }, [
                                new xp.HBox({ style: 'line fontSelectContainer' }, [
                                    new xp.CheckBox({
                                        checked: '{config.useFont}'
                                    }),
                                    new FontSelect({
                                        fonts: '{fonts}',
                                        selectedFont: '{config.fontFamily}',
                                        flex: 'stretch',
                                    }),
                                ]),
                                new xp.Label({ style: 'status', text: 'Select a font' })
                            ]),
    
                            // Text stroke
                            new UpDown({
                                label: 'Text stroke',
                                step: 0.1,
                                value: '{config.textStroke}',
                                //setterConvertor: (v: number) => (v - 50) / 100,
                                getterConvertor: (v: number) => Math.round(v * 10) / 10,
                                statusCreator: (v: number) => v > 0 ?
                                    '+' + v
                                    : v === 0 ?
                                        '0'
                                        : 'Wrong value'
                            })
                        ]),*/
                        //
                        // ---- Site list ----
                        new Popup.Tab({ tabName: 'Site list' }, [
                            //
                            // ---- Site list ----
                            new Popup.Toggle({
                                style: 'toggleWithLabel',
                                value: '{config.activeSiteList}',
                                valueOn: 0,
                                valueOff: 1,
                                labelOn: 'Whitelist Mode',
                                labelOff: 'Blacklist Mode',
                                flex: 'none',
                            }),
                            new xp.VBox({ flex: 'stretch', scrollBar: 'vertical', style: 'siteListParent blackList' }, [
                                new Popup.SiteList({
                                    sites: '{config.blackList}',
                                    /*style: (ext.config.activeSiteList===0?"zero":"one"),*/
                                    init: function (sl) { return _this.blackList = sl; }
                                }) /*,
                                new xp.HBox({ style: 'line' }, [
                                    new xp.Button({
                                        style: 'clearBlackListBtn',
                                        text: 'Clear List',
                                        onClick: ()=>{}
                                    }),
                                ]),
                                /*new HotkeyLink({
                                    commandName: 'addSite',
                                    noHotkeyText: 'setup a hotkey for adding site',
                                    hotkeyTextTemplate: 'hotkey for adding site: #HOTKEY',
                                    style: 'description'
                                })*/
                            ]),
                            new xp.VBox({ flex: 'stretch', scrollBar: 'vertical', style: 'siteListParent whiteList' }, [
                                new Popup.SiteList({
                                    sites: '{config.whiteList}',
                                    /*style: (ext.config.activeSiteList===0?"zero":"one"),*/
                                    init: function (sl) { return _this.whiteList = sl; }
                                }) /*,
                                new xp.HBox({ style: 'line' }, [
                                    new xp.Button({
                                        style: 'clearWhiteListBtn',
                                        text: 'Clear List',
                                        onClick: ()=>{}
                                    }),
                                ]),
                                /*new HotkeyLink({
                                    commandName: 'addSite',
                                    noHotkeyText: 'setup a hotkey for adding site',
                                    hotkeyTextTemplate: 'hotkey for adding site: #HOTKEY',
                                    style: 'description'
                                })*/
                            ])
                        ]),
                        new Popup.Tab({ tabName: 'Schedule' }, [
                            new xp.VBox({ name: 'modeScheduleToggle', style: 'controlContainer modeToggleContainer' }, [
                                new xp.HBox({ name: 'darkModeScheduleToggleWrap', style: 'line scheduleToggleWrap' }, [
                                    new xp.Label({
                                        text: 'DARK MODE SCHEDULE',
                                        flex: 'none',
                                    }),
                                    new Popup.Toggle({
                                        name: 'darkModeScheduleToggle',
                                        value: '{config.modeSchedule}',
                                        valueOn: 1,
                                        valueOff: 0,
                                        labelOn: '',
                                        labelOff: '',
                                        flex: 'stretch',
                                        onClick: function (el) {
                                            if (el.element["elementOff"].className.search("active") > -1) {
                                                /*this.darkScheduleTimesWrap.enabled = true;
                                                this.darkModeScheduleToggleWrap.enabled = false;*/
                                                /*console.log( "darkModeOff ", ext.config.mode );*/
                                                ext.toggleModeBasedOnSchedule("dark", true);
                                            }
                                            else {
                                                /*this.darkScheduleTimesWrap.enabled = false;
                                                this.darkModeScheduleToggleWrap.enabled = true;*/
                                                /*console.log( "darkModeOn ", ext.config.mode );*/
                                                ext.toggleModeBasedOnSchedule("dark", false);
                                            }
                                            _this.setDarkScheduleState();
                                            _this.showHideOnUntilLabel(ext, "dark");
                                            /*console.log("On ", el.element["elementOn"].className.search("active"));
                                            console.log(  );*/
                                        }
                                    }),
                                ]),
                                new xp.HBox({ name: "darkScheduleTimesWrap", style: 'line scheduleTimesWrap' /*, enabled: '{config.nightSchedule===0?true:false}'*/ }, [
                                    new xp.HBox({ flex: 'stretch', style: 'controlContainer' }, [
                                        new xp.Label({
                                            text: 'FROM',
                                            flex: 'none',
                                        }),
                                        new xp.TextBox({
                                            style: 'timeTextBox',
                                            flex: 'stretch',
                                            inputType: 'time',
                                            value: '{config.modeScheduleFrom}',
                                        }),
                                    ]),
                                    /*new xp.TextBox({
                                        flex: 'stretch',
                                        /*init: (tb) => this.textBox = tb,*/
                                    /*notifyOnKeyDown: true,*/
                                    /*onTextChange: (e) => {this.scrollToItemByText(e.newText)}* /
                                }),*/
                                    new xp.HBox({ flex: 'stretch', style: 'controlContainer' }, [
                                        new xp.Label({
                                            text: 'TO',
                                            flex: 'none',
                                        }),
                                        new xp.TextBox({
                                            style: 'timeTextBox',
                                            flex: 'stretch',
                                            inputType: 'time',
                                            value: '{config.modeScheduleTo}'
                                        }),
                                    ]),
                                ]),
                            ]),
                            new xp.VBox({ name: 'nightScheduleToggle', style: 'controlContainer modeToggleContainer' }, [
                                new xp.HBox({ name: 'nightModeScheduleToggleWrap', style: 'line scheduleToggleWrap' }, [
                                    new xp.Label({
                                        text: 'NIGHT SHIFT SCHEDULE',
                                        flex: 'none',
                                    }),
                                    new Popup.Toggle({
                                        name: 'nightModeScheduleToggle',
                                        value: '{config.nightSchedule}',
                                        valueOn: 1,
                                        valueOff: 0,
                                        labelOn: '',
                                        labelOff: '',
                                        flex: 'stretch',
                                        onClick: function (el) {
                                            if (el.element["elementOff"].className.search("active") > -1) {
                                                /*this.nightScheduleTimesWrap.enabled = true;
                                                this.nightModeScheduleToggleWrap.enabled = false;*/
                                                /*console.log( "nightModeOff ", ext.config );*/
                                                ext.toggleModeBasedOnSchedule("night", true);
                                            }
                                            else {
                                                /*this.nightScheduleTimesWrap.enabled = false;
                                                this.nightModeScheduleToggleWrap.enabled = true;*/
                                                /*console.log( "nightModeOn ", ext.config );*/
                                                ext.toggleModeBasedOnSchedule("night", false);
                                            }
                                            _this.setNightScheduleState();
                                            _this.showHideOnUntilLabel(ext, "night");
                                            /*console.log("On ", el.element["elementOn"].className.search("active"));
                                            console.log(  );*/
                                        }
                                    }),
                                ]),
                                new xp.HBox({ name: "nightScheduleTimesWrap", style: 'line scheduleTimesWrap' /*, enabled: '{config.nightSchedule===0?true:false}'*/ }, [
                                    new xp.HBox({ flex: 'stretch', style: 'controlContainer' }, [
                                        new xp.Label({
                                            text: 'FROM',
                                            flex: 'none',
                                        }),
                                        new xp.TextBox({
                                            style: 'timeTextBox',
                                            flex: 'stretch',
                                            inputType: 'time',
                                            value: '{config.nightScheduleFrom}'
                                        }),
                                    ]),
                                    /*new xp.TextBox({
                                        style: 'timeTextBox',
                                        flex: 'stretch',
                                        type: 'time'
                                        /*init: (tb) => this.textBox = tb,*/
                                    /*notifyOnKeyDown: true,*/
                                    /*onTextChange: (e) => {this.scrollToItemByText(e.newText)}* /
                                }),*/
                                    new xp.HBox({ flex: 'stretch', style: 'controlContainer' }, [
                                        new xp.Label({
                                            text: 'TO',
                                            flex: 'none',
                                        }),
                                        new xp.TextBox({
                                            style: 'timeTextBox',
                                            flex: 'stretch',
                                            inputType: 'time',
                                            value: '{config.nightScheduleTo}'
                                        }),
                                    ]),
                                ]),
                            ]),
                        ])
                    ]),
                    new xp.VBox({ style: 'confirm_clear_wrap rateConfirmClearWrap', flex: 'none' }, [
                        new xp.VBox({ style: 'confirm_box rateNowConfirmBox', flex: 'none', }, [
                            /*new xp.HBox({ style: 'confirm_heading', flex: 'none' }, [
                                new xp.Label({
                                    text: 'ALERT !',
                                    /*style: 'title'* /
                                }),
                            ]),*/
                            new xp.Button({
                                style: 'iconButton rate_close',
                                icon: '.rateCloseIcon',
                                onClick: function () {
                                    document.getElementsByClassName('rateConfirmClearWrap')[0]['style']['display'] = 'none';
                                }
                            }),
                            new xp.HBox({ style: 'confirm_text', flex: 'none' }, [
                                new xp.Label({
                                    text: 'ENJOYING LUNAR READER?',
                                }),
                            ]),
                            new xp.HBox({ style: 'confirm_btn_wrap', flex: 'none' }, [
                                new xp.Button({
                                    style: 'confirm_no',
                                    text: 'NO, I HAVE A FEEDBACK',
                                    onClick: function () {
                                        /*document.getElementsByClassName("rateConfirmClearWrap")[0]["style"].display = "none";*/
                                        chrome.tabs.create({ url: 'https://lunarreader.com/contact-us/' });
                                        /*console.log(_self.confirmBox);*/
                                        /*_self.confirmBox.domElement["style"].display = "none";*/
                                    }
                                }),
                                new xp.Button({
                                    style: 'confirm_yes',
                                    text: 'YES, GIVE IT 5 STAR',
                                    onClick: function () {
                                        chrome.tabs.create({ url: 'https://chrome.google.com/webstore/detail/pifalnbglchfojkfmechjalgbjoodlpg/reviews' });
                                    }
                                }),
                            ]),
                        ]),
                    ]),
                    new xp.Button({
                        style: 'rateNowBtn',
                        text: 'Enjoy It? Rate Now!',
                        onClick: function () {
                            document.getElementsByClassName("rateConfirmClearWrap")[0]["style"].display = "block";
                        }
                    }),
                ]);
                /*console.log(ext);*/
                /*this.initSiteToggleButton(this.siteToggle, ext, this.currentSiteName, this.siteToggle2);*/
                this.initSiteToggleButton(ext, this.currentSiteName, this.siteToggle2);
                this.handleSiteListToggle(ext);
                this.detectChromiumIssue750419();
                this.showHideOnUntilLabel(ext, "dark");
                this.showHideOnUntilLabel(ext, "night");
                this.setDarkScheduleState();
                this.setNightScheduleState();
                /*if(this.darkModeScheduleToggle.value === 0){
                    this.darkScheduleTimesWrap.enabled = true;
                    this.darkModeScheduleToggleWrap.enabled = false;
                }else{
                    this.darkScheduleTimesWrap.enabled = false;
                    this.darkModeScheduleToggleWrap.enabled = true;
                }
    
                if(this.nightModeScheduleToggle.value === 0){
                    this.nightScheduleTimesWrap.enabled = true;
                    this.nightModeScheduleToggleWrap.enabled = false;
                }else{
                    this.nightScheduleTimesWrap.enabled = false;
                    this.nightModeScheduleToggleWrap.enabled = true;
                }*/
                ext.incrementPopupOpenCount(1);
                console.log("extension opened " + (((new Date()).getTime() - ext.installedTimestamp) / 1000) + " secs after install");
                var popupOpenAfterDelay = 60 * 60 * 24;
                var maxPopupOpenCount = 100;
                var timePassedSinceInstall = ((new Date()).getTime() - ext.installedTimestamp) / 1000;
                if (timePassedSinceInstall <= popupOpenAfterDelay) {
                    if (ext.popupOpenCount === maxPopupOpenCount) {
                        /*console.log("timePassedSinceInstall ", timePassedSinceInstall, popupOpenAfterDelay);
                        console.log("ext.popupOpenCount ", ext.popupOpenCount, maxPopupOpenCount);*/
                        document.getElementsByClassName("rateConfirmClearWrap")[0]["style"].display = "block";
                        ext.incrementPopupOpenCount(-1);
                    }
                }
                if (timePassedSinceInstall > popupOpenAfterDelay && ext.popupOpenCount >= 0) {
                    /*console.log("timePassedSinceInstall ", timePassedSinceInstall, popupOpenAfterDelay);
                    console.log("ext.popupOpenCount ", ext.popupOpenCount);*/
                    document.getElementsByClassName("rateConfirmClearWrap")[0]["style"].display = "block";
                    ext.incrementPopupOpenCount(-1);
                }
            }
            PopupWindow.prototype.setDarkScheduleState = function () {
                if (this.darkModeScheduleToggle.value === 0) {
                    this.darkScheduleTimesWrap.enabled = true;
                    this.darkModeScheduleToggleWrap.enabled = false;
                }
                else {
                    this.darkScheduleTimesWrap.enabled = false;
                    this.darkModeScheduleToggleWrap.enabled = true;
                }
            };
            PopupWindow.prototype.setNightScheduleState = function () {
                if (this.nightModeScheduleToggle.value === 0) {
                    this.nightScheduleTimesWrap.enabled = true;
                    this.nightModeScheduleToggleWrap.enabled = false;
                }
                else {
                    this.nightScheduleTimesWrap.enabled = false;
                    this.nightModeScheduleToggleWrap.enabled = true;
                }
            };
            PopupWindow.prototype.getTemplate = function () {
                // Clear body
                while (document.body.lastElementChild) {
                    document.body.removeChild(document.body.lastElementChild);
                }
                return _super.prototype.getTemplate.call(this);
            };
            PopupWindow.prototype.formatTime = function (t) {
                var a = t.split(":");
                var h = Number(a[0]);
                return (h > 12 ? h - 12 : h) + ":" + a[1] + " " + (h > 12 ? "pm" : "am");
            };
            PopupWindow.prototype.showHideOnUntilLabel = function (ext, modeType) {
                if (modeType === "dark") {
                    if (ext.config.modeSchedule === 1) {
                        if (ext.isScheduleOn(ext.config.modeScheduleFrom, ext.config.modeScheduleTo)) {
                            this.modeOnUntil.text = "(On until " + this.formatTime(ext.config.modeScheduleTo) + ")";
                        }
                        else {
                            this.modeOnUntil.text = "(Off until " + this.formatTime(ext.config.modeScheduleFrom) + ")";
                        }
                    }
                    else {
                        this.modeOnUntil.text = "";
                    }
                }
                if (modeType === "night") {
                    if (ext.config.nightSchedule === 1) {
                        if (ext.isScheduleOn(ext.config.nightScheduleFrom, ext.config.nightScheduleTo)) {
                            this.nightOnUntil.text = "(On until " + this.formatTime(ext.config.nightScheduleTo) + ")";
                        }
                        else {
                            this.nightOnUntil.text = "(Off until " + this.formatTime(ext.config.nightScheduleFrom) + ")";
                        }
                    }
                    else {
                        this.nightOnUntil.text = "";
                    }
                }
            };
            PopupWindow.prototype.handleSiteListToggle = function (ext) {
                /*console.log(ext.config.activeSiteList, (ext.config.activeSiteList==1?"Black":"White"));*/
                if (ext.config.activeSiteList === 1) {
                    document.getElementsByClassName("blackList")[0]["style"].display = "block";
                    document.getElementsByClassName("whiteList")[0]["style"].display = "none";
                }
                else if (ext.config.activeSiteList === 0) {
                    document.getElementsByClassName("blackList")[0]["style"].display = "none";
                    document.getElementsByClassName("whiteList")[0]["style"].display = "block";
                }
            };
            /*private initSiteToggleButton(btn: xp.Button, ext: Extension, currentSiteName: xp.Label, siteToggle2: Toggle) {*/
            PopupWindow.prototype.initSiteToggleButton = function (ext, currentSiteName, siteToggle2) {
                var _this = this;
                /*console.log("initSiteToggleButton");*/
                var _self = this;
                ext.getActiveTabInfo(function (info) {
                    /*console.log("getActiveTabInfo ", info);*/
                    // NOTE: Disable button if toggle has no effect.
                    var toggleHasEffect = function () {
                        return (!info.isProtected
                            && !(!ext.config.invertListed
                                && info.isInDarkList));
                    };
                    /*btn.enabled = ext.enabled && toggleHasEffect();*/
                    /*siteToggle2.value = ext.enabled && toggleHasEffect();*/
                    siteToggle2.value = (ext.enabled && ext.config.blackList.indexOf(info.host) < 0) ? 1 : 0;
                    /*console.log(ext.enabled, toggleHasEffect());*/
                    var changeReg = new xp.EventRegistrar();
                    changeReg.subscribe(ext.onPropertyChanged, function (prop) {
                        if (prop === 'enabled') {
                            /*btn.enabled = ext.enabled && toggleHasEffect();*/
                            /*siteToggle2.value = ext.enabled && toggleHasEffect();*/
                            siteToggle2.value = (ext.enabled && ext.config.blackList.indexOf(info.host) < 0) ? 1 : 0;
                        }
                    });
                    /*console.log(info);*/
                    changeReg.subscribe(ext.config.onPropertyChanged, function (prop) {
                        if (prop === "mode") {
                            console.log("mode changed to ", ext.config.mode);
                        }
                        if (prop === "nightMode") {
                            console.log("nightMode changed to ", ext.config.nightMode);
                        }
                        if (prop === "modeSchedule") {
                            console.log("modeSchedule changed to ", ext.config.modeSchedule);
                        }
                        if (prop === "nightSchedule") {
                            console.log("nightSchedule changed to ", ext.config.nightSchedule);
                        }
                        if (prop === "activeSiteList") {
                            _self.handleSiteListToggle(ext);
                        }
                        if (prop === 'invertListed') {
                            /*btn.enabled = ext.enabled && toggleHasEffect();*/
                            /*siteToggle2.value = ext.enabled && toggleHasEffect();*/
                            siteToggle2.value = (ext.enabled && ext.config.blackList.indexOf(info.host) < 0) ? 1 : 0;
                        }
                    });
                    _this.onRemoved.addHandler(function () { return changeReg.unsubscribeAll(); });
                    /*console.log(info);*/
                    // Set button text
                    if (info.host) {
                        /*console.log(info.host);*/
                        // HACK: Try to break URLs at dots.
                        /*btn.text = '*';*/
                        /*const textElement = <HTMLElement>btn.domElement.querySelector('.text');
                        while (textElement.firstChild) {
                            textElement.removeChild(textElement.firstChild);
                        }*/
                        var hostParts = info.host.split('.');
                        var str = info.host;
                        hostParts.forEach(function (part, i) {
                            if (i > 0) {
                                var wbr = document.createElement('wbr');
                                var dot = document.createTextNode('.');
                            }
                            /*const text = document.createTextNode(part);
                            textElement.appendChild(text);*/
                        });
                        /*console.log(str);*/
                        currentSiteName.domElement["innerText"] = str;
                    }
                    else {
                        /*console.log("else ");*/
                        /*btn.text = 'current site';*/
                        currentSiteName.domElement["innerText"] = 'current site';
                    }
                });
            };
            PopupWindow.prototype.detectChromiumIssue750419 = function () {
                var agent = navigator.userAgent.toLowerCase();
                var m = agent.match(/chrom[e|ium]\/([^ ]+)/);
                if (m && m[1]) {
                    var chromeVersion = m[1];
                    var isWindows = navigator.platform.toLowerCase().indexOf('win') === 0;
                    var isVivaldi = agent.indexOf('vivaldi') >= 0;
                    var isYaBrowser = agent.indexOf('yabrowser') >= 0;
                    var isOpera = agent.indexOf('opr') >= 0 || agent.indexOf('opera') >= 0;
                    if (chromeVersion > '62.0.3167.0' && isWindows && !isVivaldi && !isYaBrowser && !isOpera) {
                        document.documentElement.classList.add('chromium-issue-750419');
                    }
                }
            };
            return PopupWindow;
        })(xp.Window);
        Popup.PopupWindow = PopupWindow;
    })(Popup = DarkReader.Popup || (DarkReader.Popup = {}));
})(DarkReader || (DarkReader = {}));
