var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var DarkReader;
(function (DarkReader) {
    var Popup;
    (function (Popup) {
        /**
         * Control for adjusting value using up/down buttons.
         */
        var Range = (function (_super) {
            __extends(Range, _super);
            function Range(markup) {
                var _this = this;
                _super.call(this, markup, [
                    new xp.Label({
                        style: 'range-label',
                        init: function (el) { return _this.rangeLabel = el; }
                    }),
                    new xp.HBox({ style: 'line' }, [
                        /*new xp.Button({
                            style: 'iconButton',
                            icon: '.buttonDown',
                            init: (el) => this.buttonDown = el
                        }),*/
                        new TrackBar({
                            init: function (el) { return _this.trackBar = el; },
                        }),
                        new ProgressBar({
                            init: function (el) { return _this.progressBar = el; }
                        })
                    ]),
                    new xp.Label({
                        style: 'status',
                        init: function (el) { return _this.status = el; }
                    }),
                    new xp.Label({
                        /*text: 'Less warm',*/
                        flex: 'none',
                        style: 'leftBottomLabel',
                        init: function (el) { return _this.bottomLeftLabelObj = el; }
                    }),
                    new xp.Label({
                        /*text: 'More warm',*/
                        flex: 'none',
                        style: 'rightBottomLabel',
                        init: function (el) { return _this.bottomRightLabelObj = el; }
                    }),
                ]);
                /*console.log(this.rangeLabel, this.label);*/
                this.rangeLabel.domElement.innerHTML = this.label;
                this.trackBar.domElement["step"] = this.step;
                if (this.bottomLeftLabel === undefined || this.bottomRightLabel === undefined) {
                    this.bottomLeftLabelObj.domElement.style.display = "none";
                    this.bottomRightLabelObj.domElement.style.display = "none";
                }
                else {
                    this.bottomLeftLabelObj.domElement.innerHTML = this.bottomLeftLabel;
                    this.bottomRightLabelObj.domElement.innerHTML = this.bottomRightLabel;
                }
                /*console.log(this.bottomLeftLabel, this.bottomRightLabel);*/
                /*this.trackBar.domElement["min"] = this.min;
                this.trackBar.domElement["max"] = this.max;*/
                this.trackBar.domElement.addEventListener("input", function (e) {
                    /*console.log(e.target["value"]);*/
                    _this.value = _this.getterConvertor(e.target["value"]);
                    /*this.progressBar.value = Math.round((e.target["value"]*100)/this.max);*/
                    /*console.log(this.trackBar, this.trackBar.value);*/
                    /*console.log(this.progressBar);*/
                });
                this.trackBar.domElement.addEventListener("change", function (e) {
                    /*console.log(e.target["value"]);*/
                    _this.value = _this.getterConvertor(e.target["value"]);
                    _this.onInput('value', _this.value);
                    /*this.progressBar.value = Math.round((e.target["value"]*100)/this.max);*/
                    /*console.log(this.trackBar, this.trackBar.value);*/
                    /*console.log(this.progressBar);*/
                    /*if (this.trackBar.value < 1) {
                        let value = this.trackBar.value + this.step;
                        if (value > 1) { value = 1; }
                        if (this.getterConvertor) {
                            value = this.getterConvertor(value);
                        }
                        this.onInput('value', value);
                    }*/
                });
                // Increment
                /*this.buttonUp.onClick.addHandler(() => {
                    if (this.trackBar.value < 1) {
                        let value = this.trackBar.value + this.step;
                        if (value > 1) { value = 1; }
                        if (this.getterConvertor) {
                            value = this.getterConvertor(value);
                        }
                        this.onInput('value', value);
                    }
                }, this);
                // Decrement
                this.buttonDown.onClick.addHandler(() => {
                    if (this.trackBar.value > 0) {
                        let value = this.trackBar.value - this.step;
                        if (value < 0) { value = 0; }
                        if (this.getterConvertor) {
                            value = this.getterConvertor(value);
                        }
                        this.onInput('value', value);
                    }
                }, this);
    
                // Disable buttons on boundary values
                this.buttonDown.useParentScope = false;
                this.buttonDown.express('enabled', '{value} > 0', this.trackBar);
                this.buttonUp.useParentScope = false;
                this.buttonUp.express('enabled', '{value} < 1', this.trackBar);*/
            }
            Range.prototype.getTemplate = function () {
                var t = _super.prototype.getTemplate.call(this);
                t.classList.add('UpDown');
                t.classList.add('Range');
                return t;
            };
            /*protected setDefaults() {
                super.setDefaults();
                this.step = 0.1;
            }*/
            Range.prototype.defineProperties = function () {
                var _this = this;
                _super.prototype.defineProperties.call(this);
                this.defineProperty('value', {
                    getter: function () {
                        /*console.log('getter ', this.trackBar);*/
                        if (_this.getterConvertor) {
                            return _this.getterConvertor(_this.trackBar.value);
                        }
                        else {
                            return _this.trackBar.value;
                        }
                    },
                    setter: function (v) {
                        /*console.log('setter ', this.trackBar);
                        console.log(this.statusCreator, this.status, this.status.text);*/
                        /*if (v > 1) { v = this.getterConvertor(v); }*/
                        /*console.log('setter ', v);*/
                        if (_this.setterConvertor) {
                            _this.trackBar.value = _this.setterConvertor(v);
                            _this.trackBar.domElement["value"] = _this.setterConvertor(v);
                            _this.progressBar.value = _this.setterConvertor(v) * 100;
                        } /*else {
                            console.log('else (this.setterConvertor) {');
                            this.trackBar.value = v;
                            this.progressBar.value = v;
                        }*/
                        if (_this.statusCreator) {
                            _this.status.text = _this.statusCreator(v);
                        } /*else{
                            this.status.text = v + '%';
                        }*/
                    }
                });
                this.defineProperty('label', {
                    getter: function () { return _this.trackBar.label; },
                    setter: function (v) { return _this.trackBar.label = v; }
                });
            };
            return Range;
        })(xp.VBox);
        Popup.Range = Range;
        /**
         * Progress bar.
         */
        var ProgressBar = (function (_super) {
            __extends(ProgressBar, _super);
            function ProgressBar(markup) {
                _super.call(this, markup);
            }
            // TODO: ProgressBar click...
            ProgressBar.prototype.getTemplate = function () {
                return xp.Dom.create({
                    tag: 'div',
                    attrs: { class: 'RangeProgress' },
                    children: []
                }, {});
            };
            ProgressBar.prototype.defineProperties = function () {
                var _this = this;
                _super.prototype.defineProperties.call(this);
                this.defineProperty('value', {
                    setter: function (value) {
                        /*console.log("ProgressBar ", value);*/
                        _this.domElement.style.width = 'calc( ' + (value) + '% - ' + Math.round((20 * value) / 100) + 'px)';
                        /*this.domElement.style.width = 'calc( '+(Math.round(value * 0.81))+'% - 5px)';*/
                        /*this.elementValue.style.width = 'calc( '+(Math.round(value * 0.81))+'% - 10px)';*/
                        /*if (value < 0 || value > 1) {
                            throw new Error('Track bar value must be between 0 and 1');
                        }*/
                        /*this.elementValue.value = Math.round(value * 100) + '%';*/
                    },
                    observable: true
                });
            };
            return ProgressBar;
        })(xp.Element);
        /**
         * Track bar.
         */
        var TrackBar = (function (_super) {
            __extends(TrackBar, _super);
            function TrackBar(markup) {
                _super.call(this, markup);
            }
            // TODO: Trackbar click...
            TrackBar.prototype.getTemplate = function () {
                var _this = this;
                return xp.Dom.create({
                    tag: 'input',
                    attrs: { class: 'RangeSlider', type: 'range', step: "0.1", min: "0", max: "1" },
                    children: [
                        { tag: 'span', attrs: { class: 'value' }, children: ['\u00A0'] },
                        { tag: 'label' }
                    ]
                }, {
                    '.value': function (el) { return _this.elementValue = el; },
                    'label': function (el) { return _this.elementLabel = el; }
                });
            };
            TrackBar.prototype.defineProperties = function () {
                var _this = this;
                _super.prototype.defineProperties.call(this);
                this.defineProperty('value', {
                    setter: function (value) {
                        /*console.log(value);*/
                        _this.elementValue.style.width = value + '%';
                        /*if (value < 0 || value > 1) {
                            throw new Error('Track bar value must be between 0 and 1');
                        }* /
                        /*this.elementValue.value = Math.round(value * 100) + '%';*/
                    },
                    observable: true
                });
                this.defineProperty('label', {
                    setter: function (value) {
                        _this.elementLabel.textContent = value;
                    }
                });
            };
            return TrackBar;
        })(xp.Element);
    })(Popup = DarkReader.Popup || (DarkReader.Popup = {}));
})(DarkReader || (DarkReader = {}));
