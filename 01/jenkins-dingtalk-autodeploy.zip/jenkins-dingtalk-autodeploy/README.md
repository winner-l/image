# Jenkins-Dingtalk-AutoDeploy

钉钉审批流程通过后，自动发布Jenkins-job