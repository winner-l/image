#/usr/bin/env python
# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name  :    conf.py
   Description:
   Author     :    Deniss.Wang
   date       :    2019/../..
-------------------------------------------------
   Change Activity:
                   2019/../..
-------------------------------------------------
"""

# jenkins
jenkins_server_url = 'http://jenkins.palmax.io'	# jenkins server url
jenkins_build_user = 'wangzhenghui'					# jenkins 管理员
jenkins_api_token = '11c25f76a472f046e5a907568ce76418cf'  # 管理员 token

# dingding robot token
dding_robot_token = "a4feed2325c18e7305b44e7c2f3b95f1a6ca59357de8d810482fab62c7ef7e86"

# 阿里钉钉 api 认证
# 
corpid = 'dingshqytfhir9cgdopl'
secret = 'MK6MZISNHfJR_1esgBIV-IUOwl_eVgf9cB0_Y9fNCdT6n12aP8-KzYN5-dzC4uRG'
dd_url = 'https://eco.taobao.com/router/rest'
dd_method = 'dingtalk.smartwork.bpms.processinstance.list'

# 阿里钉钉审批表单
dd_form_code_for_java = 'PROC-FBAFE2E0-BAA6-4A49-BBC8-6A91A0B70242'